
setwd("C:\\Users\\IT24100002\\Desktop\\IT24100002")   # <- change path to where file is saved
branch_data <- read.csv("Exercise (1).txt", header = TRUE)

# View first few rows
head(branch_data)

# -------------------------
# Step 2: Identify variable types and scales
# -------------------------
str(branch_data)
summary(branch_data)

# Interpretation:
# Branch        -> Categorical (Nominal ID only)
# Sales_X1      -> Numeric, Ratio scale
# Advertising_X2-> Numeric, Ratio scale
# Years_X3      -> Numeric, Interval/Ratio (discrete)

# -------------------------
# Step 3: Boxplot for Sales
# -------------------------
boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales (X1)",
        ylab = "Sales")

# Also check summary
summary(branch_data$Sales_X1)

# -------------------------
# Step 4: Five-number summary & IQR for Advertising
# -------------------------
fivenum(branch_data$Advertising_X2)    # five number summary
IQR(branch_data$Advertising_X2)        # interquartile range

# -------------------------
# Step 5: Detect outliers in Years (X3)
# -------------------------
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Apply function to Years_X3
find_outliers(branch_data$Years_X3)

# ===================================================
# END OF SCRIPT
# ===================================================
