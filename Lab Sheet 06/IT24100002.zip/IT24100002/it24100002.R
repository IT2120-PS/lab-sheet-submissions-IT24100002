setwd("C:\\Users\\IT24100002\\Desktop\\IT24100002") 


# Parameters
n <- 50          # number of students
p <- 0.85        # probability of passing

# Distribution of X
cat("X ~ Binomial(", n, ",", p, ")\n")

# Probability that at least 47 students passed
prob_atleast47 <- 1 - pbinom(46, size=n, prob=p)
cat("P(X >= 47) =", prob_atleast47, "\n\n")


# Exercise 2: 


# Parameters
lambda <- 12     # average number of calls per hour

# Distribution of X
cat("X ~ Poisson(", lambda, ")\n")

# Probability that exactly 15 calls are received
prob_15 <- dpois(15, lambda)
cat("P(X = 15) =", prob_15, "\n")

